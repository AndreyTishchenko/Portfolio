function parseFloats(string) {
  return string.split(",").map(function (string) {
    return parseFloat(string) || 0;
  });
}

function calcTransitionTime(delay, duration) {
  var length = Math.max(duration.length, delay.length),
      i = 0, time, maxTime = 0;
  while (i < length) {
    time = (delay[i] || 0) + (duration[i] || 0);
    if (time > maxTime) {
      maxTime = time;
    }
    i++;
  }
  return Math.ceil(maxTime * 1000);
}

function getTransitionTime(style) {
  return calcTransitionTime(
    parseFloats(style.transitionDelay),
    parseFloats(style.transitionDuration)
  );
}

function addClass(element, className) {
  return new Promise(function (resolve) {
    element.classList.add(className);
    var delay = getTransitionTime(getComputedStyle(element));
    setTimeout(function () {
      resolve(element);
    }, delay);
  });
}

window.onload = function () {
  var el = document.querySelector(".animated");
  addClass(el, "move").then(function () {
    alert("done");
  });
};
